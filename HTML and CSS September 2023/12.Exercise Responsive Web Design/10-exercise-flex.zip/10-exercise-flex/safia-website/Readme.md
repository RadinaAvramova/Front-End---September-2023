# Safia Website

This is a small project for learnin purposes. We will be using the [Safia SaaS Template (Free Download)](https://www.figma.com/community/file/892582971189995704) design from Figma. This is a free Figma template brought to you by the [Flowbase Team](https://www.flowbase.co/)! 

## Design link: 
- figma - https://www.figma.com/community/file/892582971189995704
- local file - Safia-Landing-Page.png
## Flowbase Team
https://www.flowbase.co

![Safia](./Safia-Landing-Page.png)